<?php
declare(strict_types=1);
require_once __DIR__ . '/config/config.php';
$user = require_user();

$statusFilter = trim((string) ($_GET['status'] ?? ''));
$allowedStatuses = ['Pending', 'Confirmed', 'Completed', 'Cancelled'];
$params = ['user_id' => $user['id']];
$sql = 'SELECT a.*, s.name AS service_name FROM appointments a
        JOIN services s ON s.id = a.service_id
        WHERE a.user_id = :user_id';
if (in_array($statusFilter, $allowedStatuses, true)) {
    $sql .= ' AND a.status = :status';
    $params['status'] = $statusFilter;
} else {
    $statusFilter = '';
}
$sql .= ' ORDER BY a.appointment_date DESC, a.appointment_time DESC';
$statement = db()->prepare($sql);
$statement->execute($params);
$appointments = $statement->fetchAll();

$pageTitle = 'My appointments';
$activePage = 'appointments';
require __DIR__ . '/includes/header.php';
?>
<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-end gap-3 mb-4">
    <div><span class="eyebrow">Your appointments</span><h1 class="h2 page-heading mt-2 mb-1">Visits, all in one place.</h1><p class="page-subtitle mb-0">Review status or make changes to an upcoming appointment.</p></div>
    <a class="btn btn-primary px-4" href="<?= e(url('book-appointment.php')) ?>">＋ Book an appointment</a>
</div>
<section class="surface-card filter-bar mb-3">
    <form class="row g-2 align-items-end" method="get" action="<?= e(url('my-appointments.php')) ?>">
        <div class="col-sm-8 col-md-5"><label class="form-label mb-1" for="status">Filter by status</label><select class="form-select" id="status" name="status"><option value="">All statuses</option><?php foreach ($allowedStatuses as $status): ?><option value="<?= e($status) ?>" <?= $statusFilter === $status ? 'selected' : '' ?>><?= e($status) ?></option><?php endforeach; ?></select></div>
        <div class="col-auto"><button class="btn btn-outline-primary" type="submit">Apply filter</button></div>
        <?php if ($statusFilter !== ''): ?><div class="col-auto"><a class="btn btn-link" href="<?= e(url('my-appointments.php')) ?>">Clear</a></div><?php endif; ?>
    </form>
</section>
<section class="surface-card p-3 p-lg-4">
    <?php if (!$appointments): ?>
        <div class="empty-state"><div class="empty-icon" aria-hidden="true">◷</div><h2 class="h5 section-title">Nothing to show yet</h2><p class="text-muted-custom">Try another filter or book a new appointment.</p><a class="btn btn-primary" href="<?= e(url('book-appointment.php')) ?>">Book an appointment</a></div>
    <?php else: ?>
        <div class="table-wrap"><table class="table mb-0"><thead><tr><th>Appointment</th><th>Contact</th><th>Date &amp; time</th><th>Status</th><th class="text-end">Actions</th></tr></thead><tbody>
        <?php foreach ($appointments as $appointment): ?>
            <?php $canChange = in_array($appointment['status'], ['Pending', 'Confirmed'], true) && $appointment['appointment_date'] >= date('Y-m-d'); ?>
            <tr>
                <td><div class="fw-semibold"><?= e($appointment['service_name']) ?></div><div class="small text-muted-custom"><?= e($appointment['contact_name']) ?></div></td>
                <td><div><?= e($appointment['contact_email']) ?></div><div class="small text-muted-custom"><?= e($appointment['contact_phone']) ?></div></td>
                <td><?= e(date('M j, Y', strtotime($appointment['appointment_date']))) ?><div class="small text-muted-custom"><?= e(date('g:i A', strtotime($appointment['appointment_time']))) ?></div></td>
                <td><span class="status-badge <?= e(status_badge_class($appointment['status'])) ?>"><?= e($appointment['status']) ?></span></td>
                <td class="text-end text-nowrap">
                    <?php if ($canChange): ?>
                        <a class="btn btn-sm btn-outline-primary" href="<?= e(url('edit-appointment.php?id=' . (int) $appointment['id'])) ?>">Edit</a>
                        <form class="d-inline" method="post" action="<?= e(url('cancel-appointment.php')) ?>" onsubmit="return confirm('Cancel this appointment?');"><?= csrf_field() ?><input type="hidden" name="appointment_id" value="<?= (int) $appointment['id'] ?>"><button class="btn btn-sm btn-outline-danger" type="submit">Cancel</button></form>
                    <?php else: ?><span class="small text-muted-custom">—</span><?php endif; ?>
                </td>
            </tr>
            <?php if (!empty($appointment['description'])): ?><tr class="small"><td colspan="5" class="pt-0 text-muted-custom"><strong>Note:</strong> <?= nl2br(e($appointment['description'])) ?></td></tr><?php endif; ?>
        <?php endforeach; ?>
        </tbody></table></div>
    <?php endif; ?>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>
