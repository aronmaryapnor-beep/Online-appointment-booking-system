(() => {
  "use strict";

  document.querySelectorAll("form[data-validate]").forEach((form) => {
    form.addEventListener("submit", (event) => {
      if (!form.checkValidity()) {
        event.preventDefault();
        event.stopPropagation();
      }
      form.classList.add("was-validated");
    });
  });

  const bookingForm = document.querySelector("[data-booking-form]");
  if (!bookingForm) return;

  const dateInput = bookingForm.querySelector("[name='appointment_date']");
  const slotsRoot = document.querySelector("[data-slot-list]");
  const slotInput = bookingForm.querySelector("[name='appointment_time']");
  const availabilityUrl = bookingForm.dataset.availabilityUrl;
  const excludeId = bookingForm.dataset.excludeId;

  const renderSlots = (slots) => {
    slotsRoot.replaceChildren();
    if (!slots.length) {
      slotsRoot.innerHTML = '<div class="slot-empty">No times are available for this date. Please choose another day.</div>';
      return;
    }
    slots.forEach((slot) => {
      const button = document.createElement("button");
      button.type = "button";
      button.className = "slot-option";
      button.textContent = slot.label;
      button.dataset.time = slot.value;
      if (slotInput.value === slot.value) button.classList.add("selected");
      button.addEventListener("click", () => {
        slotsRoot.querySelectorAll(".slot-option").forEach((item) => item.classList.remove("selected"));
        button.classList.add("selected");
        slotInput.value = slot.value;
        slotInput.dispatchEvent(new Event("change", { bubbles: true }));
      });
      slotsRoot.append(button);
    });
  };

  const loadSlots = async () => {
    slotsRoot.innerHTML = '<div class="slot-empty">Checking available times…</div>';
    slotInput.value = "";
    if (!dateInput.value) {
      slotsRoot.innerHTML = '<div class="slot-empty">Choose a date to see available times.</div>';
      return;
    }
    try {
      const params = new URLSearchParams({ date: dateInput.value });
      if (excludeId) params.set("exclude_id", excludeId);
      const response = await fetch(`${availabilityUrl}?${params.toString()}`, {
        headers: { Accept: "application/json" },
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.message || "Could not load available times.");
      renderSlots(result.slots);
    } catch (error) {
      slotsRoot.innerHTML = `<div class="slot-empty text-danger">${String(error.message || "Unable to load times.")}</div>`;
    }
  };

  dateInput.addEventListener("change", () => {
    slotInput.value = "";
    loadSlots();
  });
  if (dateInput.value) loadSlots();

  bookingForm.addEventListener("submit", (event) => {
    if (!slotInput.value) {
      event.preventDefault();
      event.stopPropagation();
      slotsRoot.classList.add("slot-list-invalid");
      slotsRoot.scrollIntoView({ behavior: "smooth", block: "center" });
    }
  });
})();
