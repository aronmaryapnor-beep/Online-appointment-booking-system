<?php
declare(strict_types=1);
require_once __DIR__ . '/config/config.php';
$user = require_user();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    header('Allow: POST');
    exit('Use the cancel button to cancel an appointment.');
}
verify_csrf();
$appointmentId = filter_input(INPUT_POST, 'appointment_id', FILTER_VALIDATE_INT);
if (!$appointmentId) {
    flash('danger', 'That appointment could not be found.');
    redirect('my-appointments.php');
}
$statement = db()->prepare(
    "UPDATE appointments SET status = 'Cancelled'
     WHERE id = :id AND user_id = :user_id
       AND status IN ('Pending', 'Confirmed')
       AND appointment_date >= CURDATE()"
);
$statement->execute(['id' => $appointmentId, 'user_id' => $user['id']]);
if ($statement->rowCount() === 1) {
    flash('success', 'Your appointment has been cancelled. Its time slot is available again.');
} else {
    flash('warning', 'This appointment could not be cancelled. It may already be completed or cancelled.');
}
redirect('my-appointments.php');
