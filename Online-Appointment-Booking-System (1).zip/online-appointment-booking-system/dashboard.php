<?php
declare(strict_types=1);
require_once __DIR__ . '/config/config.php';
$user = require_user();
$pdo = db();

$summaryStatement = $pdo->prepare(
    "SELECT
        COUNT(*) AS total,
        SUM(status IN ('Pending', 'Confirmed') AND appointment_date >= CURDATE()) AS upcoming,
        SUM(status = 'Pending') AS pending
     FROM appointments WHERE user_id = :user_id"
);
$summaryStatement->execute(['user_id' => $user['id']]);
$summary = $summaryStatement->fetch() ?: ['total' => 0, 'upcoming' => 0, 'pending' => 0];
$recentStatement = $pdo->prepare(
    'SELECT a.*, s.name AS service_name FROM appointments a
     JOIN services s ON s.id = a.service_id
     WHERE a.user_id = :user_id
     ORDER BY a.appointment_date DESC, a.appointment_time DESC LIMIT 5'
);
$recentStatement->execute(['user_id' => $user['id']]);
$appointments = $recentStatement->fetchAll();

$pageTitle = 'Your dashboard';
$activePage = 'dashboard';
require __DIR__ . '/includes/header.php';
?>
<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-end gap-3 mb-4">
    <div><span class="eyebrow">Your space</span><h1 class="h2 page-heading mt-2 mb-1">Good to see you, <?= e(explode(' ', $user['name'])[0]) ?>.</h1><p class="page-subtitle mb-0">A quick look at your appointments and what’s coming up.</p></div>
    <a class="btn btn-primary px-4" href="<?= e(url('book-appointment.php')) ?>">＋ Book an appointment</a>
</div>
<section class="row g-3 mb-4" aria-label="Appointment summary">
    <div class="col-6 col-lg-4"><div class="surface-card stat-card h-100"><div class="stat-value"><?= (int) $summary['upcoming'] ?></div><div class="stat-label">Upcoming appointments</div></div></div>
    <div class="col-6 col-lg-4"><div class="surface-card stat-card h-100"><div class="stat-value"><?= (int) $summary['pending'] ?></div><div class="stat-label">Awaiting confirmation</div></div></div>
    <div class="col-12 col-lg-4"><div class="surface-card stat-card h-100"><div class="stat-value"><?= (int) $summary['total'] ?></div><div class="stat-label">Appointments on your account</div></div></div>
</section>
<section class="surface-card p-3 p-lg-4">
    <div class="d-flex justify-content-between align-items-center gap-3 mb-3">
        <div><span class="eyebrow">Your schedule</span><h2 class="h4 section-title mt-2 mb-0">Recent appointments</h2></div>
        <a class="btn btn-sm btn-outline-primary" href="<?= e(url('my-appointments.php')) ?>">View all</a>
    </div>
    <?php if (!$appointments): ?>
        <div class="empty-state"><div class="empty-icon" aria-hidden="true">＋</div><h3 class="h5 section-title">No appointments yet</h3><p class="text-muted-custom">When you book a visit, it will appear here.</p><a class="btn btn-primary" href="<?= e(url('book-appointment.php')) ?>">Book your first visit</a></div>
    <?php else: ?>
        <div class="table-wrap"><table class="table mb-0"><thead><tr><th>Service</th><th>Date &amp; time</th><th>Status</th><th></th></tr></thead><tbody>
        <?php foreach ($appointments as $appointment): ?>
            <tr><td class="fw-semibold"><?= e($appointment['service_name']) ?></td><td><?= e(date('M j, Y', strtotime($appointment['appointment_date']))) ?><div class="small text-muted-custom"><?= e(date('g:i A', strtotime($appointment['appointment_time']))) ?></div></td><td><span class="status-badge <?= e(status_badge_class($appointment['status'])) ?>"><?= e($appointment['status']) ?></span></td><td class="text-end"><a href="<?= e(url('my-appointments.php')) ?>">Details</a></td></tr>
        <?php endforeach; ?>
        </tbody></table></div>
    <?php endif; ?>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>
