<?php
declare(strict_types=1);

/*
 * Local setup: copy config.local.example.php to config.local.php and edit it,
 * or set DB_HOST, DB_PORT, DB_NAME, DB_USER and DB_PASS in your environment.
 */
$localConfigFile = __DIR__ . '/config.local.php';
$localConfig = is_file($localConfigFile) ? require $localConfigFile : [];
$localConfig = is_array($localConfig) ? $localConfig : [];

$setting = static function (string $key, mixed $default = '') use ($localConfig): mixed {
    $environmentValue = getenv($key);
    return $environmentValue !== false ? $environmentValue : ($localConfig[$key] ?? $default);
};

define('DB_HOST', (string) $setting('DB_HOST', '127.0.0.1'));
define('DB_PORT', (string) $setting('DB_PORT', '3306'));
define('DB_NAME', (string) $setting('DB_NAME', 'appointment_booking_system'));
define('DB_USER', (string) $setting('DB_USER', 'root'));
define('DB_PASS', (string) $setting('DB_PASS', ''));
define('DB_CHARSET', 'utf8mb4');
define('APP_TIMEZONE', (string) $setting('APP_TIMEZONE', 'Asia/Kolkata'));

$configuredBasePath = (string) $setting('APP_BASE_PATH', '');
if ($configuredBasePath === '') {
    $scriptDirectory = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/'));
    if (preg_match('~/(admin|api)$~', $scriptDirectory)) {
        $scriptDirectory = dirname($scriptDirectory);
    }
    $configuredBasePath = $scriptDirectory === '/' || $scriptDirectory === '.' ? '' : $scriptDirectory;
}
define('APP_BASE_PATH', rtrim($configuredBasePath, '/'));
define('APP_NAME', 'Appointmently');

date_default_timezone_set(APP_TIMEZONE);

$isHttps = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
if (session_status() !== PHP_SESSION_ACTIVE) {
    ini_set('session.use_strict_mode', '1');
    session_set_cookie_params([
        'httponly' => true,
        'secure' => $isHttps,
        'samesite' => 'Lax',
        'path' => APP_BASE_PATH !== '' ? APP_BASE_PATH . '/' : '/',
    ]);
    session_start();
}

require_once __DIR__ . '/../includes/helpers.php';

function db(): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) {
        return $pdo;
    }

    $dsn = sprintf('mysql:host=%s;port=%s;dbname=%s;charset=%s', DB_HOST, DB_PORT, DB_NAME, DB_CHARSET);
    try {
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);
        $timezoneOffset = (new DateTimeImmutable('now', new DateTimeZone(APP_TIMEZONE)))->format('P');
        $pdo->exec('SET time_zone = ' . $pdo->quote($timezoneOffset));
    } catch (PDOException $exception) {
        error_log('Database connection failed: ' . $exception->getMessage());
        http_response_code(500);
        exit('Unable to connect to the database. Check config/config.local.php and confirm MySQL is running.');
    }

    return $pdo;
}
