<?php
/*
 * Copy this file to config.local.php and enter your local database settings.
 * For a standard local XAMPP install, MySQL commonly uses user "root" with
 * a blank password. Set a password if your MySQL account requires one.
 */
return [
    'DB_HOST' => '127.0.0.1',
    'DB_PORT' => '3306',
    'DB_NAME' => 'appointment_booking_system',
    'DB_USER' => 'root',
    'DB_PASS' => '',
    // Set to '/online-appointment-booking-system' if the folder is in htdocs.
    'APP_BASE_PATH' => '',
    'APP_TIMEZONE' => 'Asia/Kolkata',
];
