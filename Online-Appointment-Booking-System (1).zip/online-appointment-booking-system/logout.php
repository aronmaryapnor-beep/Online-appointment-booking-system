<?php
declare(strict_types=1);
require_once __DIR__ . '/config/config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    header('Allow: POST');
    exit('Use the sign-out button to end your session.');
}
verify_csrf();
$_SESSION = [];
if (ini_get('session.use_cookies')) {
    $cookie = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000, $cookie['path'], $cookie['domain'] ?? '', (bool) $cookie['secure'], (bool) $cookie['httponly']);
}
session_destroy();
header('Location: ' . url('index.php'));
exit;
