<?php
declare(strict_types=1);
require_once __DIR__ . '/config/config.php';
$user = require_user();
$appointmentId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT) ?: filter_input(INPUT_POST, 'appointment_id', FILTER_VALIDATE_INT);
if (!$appointmentId) {
    http_response_code(400);
    exit('A valid appointment ID is required.');
}
$pdo = db();
$appointment = appointment_by_id_for_user($pdo, (int) $appointmentId, $user['id']);
if (!$appointment || !in_array($appointment['status'], ['Pending', 'Confirmed'], true) || $appointment['appointment_date'] < date('Y-m-d')) {
    flash('warning', 'This appointment can no longer be edited.');
    redirect('my-appointments.php');
}
$serviceStatement = $pdo->prepare('SELECT id, name, duration_minutes FROM services WHERE is_active = 1 OR id = :current_service_id ORDER BY name');
$serviceStatement->execute(['current_service_id' => $appointment['service_id']]);
$services = $serviceStatement->fetchAll();
$errors = [];
$contactName = $appointment['contact_name'];
$contactEmail = $appointment['contact_email'];
$contactPhone = $appointment['contact_phone'];
$serviceId = (string) $appointment['service_id'];
$appointmentDate = $appointment['appointment_date'];
$appointmentTime = substr((string) $appointment['appointment_time'], 0, 5);
$description = (string) ($appointment['description'] ?? '');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $contactName = trim((string) ($_POST['contact_name'] ?? ''));
    $contactEmail = strtolower(trim((string) ($_POST['contact_email'] ?? '')));
    $contactPhone = trim((string) ($_POST['contact_phone'] ?? ''));
    $serviceId = (string) ($_POST['service_id'] ?? '');
    $appointmentDate = trim((string) ($_POST['appointment_date'] ?? ''));
    $appointmentTime = trim((string) ($_POST['appointment_time'] ?? ''));
    $description = trim((string) ($_POST['description'] ?? ''));

    if ($contactName === '' || strlen($contactName) > 100) $errors[] = 'Enter your full name (up to 100 characters).';
    if (!valid_email($contactEmail) || strlen($contactEmail) > 190) $errors[] = 'Enter a valid email address.';
    if (!valid_phone($contactPhone)) $errors[] = 'Enter a valid phone number with at least 7 digits.';
    if (!ctype_digit($serviceId) || !in_array((int) $serviceId, array_map(static fn($service) => (int) $service['id'], $services), true)) $errors[] = 'Choose an active service.';
    if (!valid_date($appointmentDate) || $appointmentDate < date('Y-m-d')) $errors[] = 'Choose today or a future appointment date.';
    if (!in_array($appointmentTime, allowed_time_slots(), true)) $errors[] = 'Choose an available appointment time.';
    if (strlen($description) > 2000) $errors[] = 'The description must be 2,000 characters or fewer.';
    if (!$errors && $appointmentDate === date('Y-m-d') && $appointmentTime <= date('H:i')) $errors[] = 'Choose a later time for today.';

    if (!$errors) {
        try {
            $update = $pdo->prepare(
                "UPDATE appointments SET
                    service_id = :service_id, contact_name = :contact_name,
                    contact_email = :contact_email, contact_phone = :contact_phone,
                    appointment_date = :appointment_date, appointment_time = :appointment_time,
                    description = :description, status = 'Pending'
                 WHERE id = :id AND user_id = :user_id
                   AND status IN ('Pending', 'Confirmed')"
            );
            $update->execute([
                'service_id' => (int) $serviceId,
                'contact_name' => $contactName,
                'contact_email' => $contactEmail,
                'contact_phone' => $contactPhone,
                'appointment_date' => $appointmentDate,
                'appointment_time' => $appointmentTime,
                'description' => $description !== '' ? $description : null,
                'id' => (int) $appointmentId,
                'user_id' => $user['id'],
            ]);
            flash('success', 'Your appointment was updated. Its status is now pending confirmation.');
            redirect('my-appointments.php');
        } catch (PDOException $exception) {
            if ($exception->getCode() === '23000') {
                $errors[] = 'That time was just booked. Please choose another available slot.';
            } else {
                throw $exception;
            }
        }
    }
}

$pageTitle = 'Edit appointment';
require __DIR__ . '/includes/header.php';
?>
<div class="form-shell">
    <div class="mb-4"><span class="eyebrow">Make a change</span><h1 class="h2 page-heading mt-2 mb-2">Edit your appointment</h1><p class="page-subtitle mb-0">Updating a confirmed appointment sends it back for confirmation.</p></div>
    <div class="surface-card form-card">
        <?php if ($errors): ?><div class="alert alert-danger" role="alert"><ul class="mb-0"><?php foreach ($errors as $error): ?><li><?= e($error) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
        <form method="post" action="<?= e(url('edit-appointment.php')) ?>" data-booking-form data-availability-url="<?= e(url('api/available-slots.php')) ?>" data-exclude-id="<?= (int) $appointmentId ?>" data-validate novalidate>
            <?= csrf_field() ?><input type="hidden" name="appointment_id" value="<?= (int) $appointmentId ?>">
            <div class="row g-3">
                <div class="col-md-6"><label class="form-label" for="contact_name">Your name</label><input class="form-control" id="contact_name" name="contact_name" value="<?= e($contactName) ?>" maxlength="100" required></div>
                <div class="col-md-6"><label class="form-label" for="contact_email">Email address</label><input class="form-control" id="contact_email" type="email" name="contact_email" value="<?= e($contactEmail) ?>" maxlength="190" required></div>
                <div class="col-md-6"><label class="form-label" for="contact_phone">Phone number</label><input class="form-control" id="contact_phone" name="contact_phone" value="<?= e($contactPhone) ?>" maxlength="24" pattern="[0-9+().\-\s]{7,24}" required></div>
                <div class="col-md-6"><label class="form-label" for="service_id">Service</label><select class="form-select" id="service_id" name="service_id" required><option value="">Select a service</option><?php foreach ($services as $service): ?><option value="<?= (int) $service['id'] ?>" <?= (string) $service['id'] === $serviceId ? 'selected' : '' ?>><?= e($service['name']) ?> · <?= (int) $service['duration_minutes'] ?> min</option><?php endforeach; ?></select></div>
                <div class="col-md-6"><label class="form-label" for="appointment_date">Appointment date</label><input class="form-control" id="appointment_date" type="date" name="appointment_date" min="<?= e(date('Y-m-d')) ?>" value="<?= e($appointmentDate) ?>" required></div>
                <div class="col-12"><label class="form-label d-block">Available time slots</label><div class="slot-list mb-2" data-slot-list aria-live="polite"><div class="slot-empty">Checking available times…</div></div><input type="hidden" name="appointment_time" value="<?= e($appointmentTime) ?>"></div>
                <div class="col-12"><label class="form-label" for="description">Appointment description <span class="text-muted-custom fw-normal">(optional)</span></label><textarea class="form-control" id="description" name="description" maxlength="2000"><?= e($description) ?></textarea></div>
                <div class="col-12 d-flex flex-column flex-sm-row gap-2 mt-4"><button class="btn btn-primary px-4" type="submit">Save changes</button><a class="btn btn-outline-secondary px-4" href="<?= e(url('my-appointments.php')) ?>">Cancel</a></div>
            </div>
        </form>
    </div>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
