<?php
declare(strict_types=1);
require_once __DIR__ . '/config/config.php';

if (current_user()) {
    redirect('dashboard.php');
}

$errors = [];
$name = '';
$email = '';
$phone = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $name = trim((string) ($_POST['name'] ?? ''));
    $email = strtolower(trim((string) ($_POST['email'] ?? '')));
    $phone = trim((string) ($_POST['phone'] ?? ''));
    $password = (string) ($_POST['password'] ?? '');
    $passwordConfirmation = (string) ($_POST['password_confirmation'] ?? '');

    if ($name === '' || strlen($name) > 100) {
        $errors[] = 'Enter your name (up to 100 characters).';
    }
    if (!valid_email($email) || strlen($email) > 190) {
        $errors[] = 'Enter a valid email address.';
    }
    if (!valid_phone($phone)) {
        $errors[] = 'Enter a valid phone number with at least 7 digits.';
    }
    if (strlen($password) < 8 || strlen($password) > 72) {
        $errors[] = 'Your password must be 8–72 characters long.';
    }
    if ($password !== $passwordConfirmation) {
        $errors[] = 'The passwords do not match.';
    }

    if (!$errors) {
        try {
            $statement = db()->prepare(
                'INSERT INTO users (name, email, phone, password_hash)
                 VALUES (:name, :email, :phone, :password_hash)'
            );
            $statement->execute([
                'name' => $name,
                'email' => $email,
                'phone' => $phone,
                'password_hash' => password_hash($password, PASSWORD_DEFAULT),
            ]);
            session_regenerate_id(true);
            $_SESSION['user_id'] = (int) db()->lastInsertId();
            $_SESSION['user_name'] = $name;
            $_SESSION['user_email'] = $email;
            flash('success', 'Your account is ready. Welcome!');
            redirect('dashboard.php');
        } catch (PDOException $exception) {
            if ($exception->getCode() === '23000') {
                $errors[] = 'An account with this email already exists.';
            } else {
                throw $exception;
            }
        }
    }
}

$pageTitle = 'Create your account';
require __DIR__ . '/includes/header.php';
?>
<section class="auth-wrap">
    <div class="text-center mb-4">
        <div class="auth-mark mx-auto mb-3" aria-hidden="true">A</div>
        <span class="eyebrow">Your schedule, in one place</span>
        <h1 class="h2 page-heading mt-2 mb-2">Create your account</h1>
        <p class="page-subtitle mx-auto mb-0">A few details and you’ll be ready to book your first appointment.</p>
    </div>
    <div class="surface-card form-card">
        <?php if ($errors): ?><div class="alert alert-danger" role="alert"><ul class="mb-0"><?php foreach ($errors as $error): ?><li><?= e($error) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
        <form method="post" action="<?= e(url('register.php')) ?>" data-validate novalidate>
            <?= csrf_field() ?>
            <div class="mb-3"><label class="form-label" for="name">Full name</label><input class="form-control" id="name" name="name" value="<?= e($name) ?>" maxlength="100" autocomplete="name" required></div>
            <div class="mb-3"><label class="form-label" for="email">Email address</label><input class="form-control" id="email" type="email" name="email" value="<?= e($email) ?>" maxlength="190" autocomplete="email" required></div>
            <div class="mb-3"><label class="form-label" for="phone">Phone number</label><input class="form-control" id="phone" name="phone" value="<?= e($phone) ?>" minlength="7" maxlength="24" pattern="[0-9+().\-\s]{7,24}" autocomplete="tel" required><div class="form-text">Include your country code if needed.</div></div>
            <div class="row g-3 mb-4">
                <div class="col-sm-6"><label class="form-label" for="password">Password</label><input class="form-control" id="password" type="password" name="password" minlength="8" maxlength="72" autocomplete="new-password" required><div class="form-text">At least 8 characters.</div></div>
                <div class="col-sm-6"><label class="form-label" for="password_confirmation">Confirm password</label><input class="form-control" id="password_confirmation" type="password" name="password_confirmation" minlength="8" maxlength="72" autocomplete="new-password" required></div>
            </div>
            <button class="btn btn-primary w-100 py-2" type="submit">Create account</button>
        </form>
        <p class="text-center text-muted-custom mt-4 mb-0">Already registered? <a href="<?= e(url('login.php')) ?>">Sign in</a></p>
    </div>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>
