<?php
declare(strict_types=1);
require_once __DIR__ . '/config/config.php';

$pdo = db();
$serviceCount = (int) $pdo->query('SELECT COUNT(*) FROM services WHERE is_active = 1')->fetchColumn();
$pageTitle = 'Book appointments with ease';
$activePage = 'home';
require __DIR__ . '/includes/header.php';
?>
<section class="hero-shell mb-4 mb-lg-5">
    <div class="hero-grid">
        <div class="hero-content">
            <span class="hero-pill mb-4"><span aria-hidden="true">●</span> A simpler way to plan your visit</span>
            <h1 class="hero-title mb-4">Your time matters.<br>Make it count.</h1>
            <p class="hero-copy mb-4">Book, manage, and keep track of appointments in one calm, organized place. Pick a service, choose an open time, and leave the rest to us.</p>
            <div class="d-flex flex-wrap gap-2">
                <a class="btn btn-light btn-lg px-4" href="<?= e(url(current_user() ? 'book-appointment.php' : 'register.php')) ?>">Book an appointment <span aria-hidden="true">→</span></a>
                <a class="btn btn-outline-light btn-lg px-4" href="<?= e(url(current_user() ? 'dashboard.php' : 'login.php')) ?>"><?= current_user() ? 'Go to dashboard' : 'Sign in' ?></a>
            </div>
        </div>
        <aside class="hero-note">
            <div class="d-flex align-items-center justify-content-between mb-4">
                <span class="hero-pill">Scheduling made simple</span>
                <span aria-hidden="true">✦</span>
            </div>
            <p class="h5 fw-bold mb-2">A little more organized.</p>
            <p class="mb-4 text-white-50">See available times before you book. Manage every visit from your personal dashboard.</p>
            <div class="d-flex justify-content-between border-top border-white border-opacity-25 pt-3">
                <span class="text-white-50 small">Services available</span>
                <strong><?= $serviceCount ?></strong>
            </div>
        </aside>
    </div>
</section>

<section class="row g-3 g-lg-4 mb-5" aria-label="How it works">
    <div class="col-md-4"><article class="surface-card feature-card">
        <div class="feature-icon mb-3" aria-hidden="true">01</div>
        <h2 class="h5 section-title">Choose your service</h2>
        <p class="text-muted-custom mb-0">Browse the services on offer and tell us what you need when you book.</p>
    </article></div>
    <div class="col-md-4"><article class="surface-card feature-card">
        <div class="feature-icon mb-3" aria-hidden="true">02</div>
        <h2 class="h5 section-title">Pick an open time</h2>
        <p class="text-muted-custom mb-0">Available slots update as bookings change, so you only see times you can request.</p>
    </article></div>
    <div class="col-md-4"><article class="surface-card feature-card">
        <div class="feature-icon mb-3" aria-hidden="true">03</div>
        <h2 class="h5 section-title">Stay in the loop</h2>
        <p class="text-muted-custom mb-0">Check your appointment status, make changes, or cancel from your account.</p>
    </article></div>
</section>
<section class="d-flex flex-column flex-md-row align-items-md-center justify-content-between gap-3 surface-card p-4 p-lg-5">
    <div><span class="eyebrow">Ready when you are</span><h2 class="h3 section-title mt-2 mb-1">Make your next appointment simple.</h2><p class="text-muted-custom mb-0">Create an account to see available services and times.</p></div>
    <a class="btn btn-primary px-4 py-2" href="<?= e(url(current_user() ? 'book-appointment.php' : 'register.php')) ?>">Get started</a>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>
