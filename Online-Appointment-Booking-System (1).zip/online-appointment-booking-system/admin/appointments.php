<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/config.php';
require_admin();

$search = trim((string) ($_GET['q'] ?? ''));
$status = trim((string) ($_GET['status'] ?? ''));
$date = trim((string) ($_GET['date'] ?? ''));
$validStatuses = ['Pending', 'Confirmed', 'Completed', 'Cancelled'];
$conditions = [];
$params = [];
if ($search !== '') {
    $conditions[] = '(a.contact_name LIKE :name OR a.contact_email LIKE :email OR a.contact_phone LIKE :phone OR s.name LIKE :service)';
    $needle = '%' . $search . '%';
    $params += ['name' => $needle, 'email' => $needle, 'phone' => $needle, 'service' => $needle];
}
if (in_array($status, $validStatuses, true)) {
    $conditions[] = 'a.status = :status';
    $params['status'] = $status;
} else {
    $status = '';
}
if ($date !== '' && valid_date($date)) {
    $conditions[] = 'a.appointment_date = :appointment_date';
    $params['appointment_date'] = $date;
} else {
    $date = '';
}
$sql = 'SELECT a.*, s.name AS service_name FROM appointments a
        JOIN services s ON s.id = a.service_id';
if ($conditions) $sql .= ' WHERE ' . implode(' AND ', $conditions);
$sql .= ' ORDER BY a.appointment_date DESC, a.appointment_time DESC LIMIT 500';
$statement = db()->prepare($sql);
$statement->execute($params);
$appointments = $statement->fetchAll();

$pageTitle = 'Manage appointments';
require __DIR__ . '/../includes/header.php';
?>
<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-end gap-3 mb-4">
    <div><span class="eyebrow">Administration</span><h1 class="h2 page-heading mt-2 mb-1">Manage appointments</h1><p class="page-subtitle mb-0">Find a booking, review its details, and update its status.</p></div>
    <a class="btn btn-outline-primary" href="<?= e(url('admin/dashboard.php')) ?>">← Dashboard</a>
</div>
<section class="surface-card filter-bar mb-3">
    <form class="row g-2 align-items-end" method="get" action="<?= e(url('admin/appointments.php')) ?>">
        <div class="col-md-4"><label class="form-label mb-1" for="q">Search</label><input class="form-control" id="q" name="q" value="<?= e($search) ?>" placeholder="Name, email, phone, service"></div>
        <div class="col-sm-6 col-md-3"><label class="form-label mb-1" for="status">Status</label><select class="form-select" id="status" name="status"><option value="">All statuses</option><?php foreach ($validStatuses as $option): ?><option value="<?= e($option) ?>" <?= $status === $option ? 'selected' : '' ?>><?= e($option) ?></option><?php endforeach; ?></select></div>
        <div class="col-sm-6 col-md-3"><label class="form-label mb-1" for="date">Appointment date</label><input class="form-control" id="date" type="date" name="date" value="<?= e($date) ?>"></div>
        <div class="col-auto"><button class="btn btn-primary" type="submit">Filter</button></div>
        <?php if ($search !== '' || $status !== '' || $date !== ''): ?><div class="col-auto"><a class="btn btn-link" href="<?= e(url('admin/appointments.php')) ?>">Clear</a></div><?php endif; ?>
    </form>
</section>
<section class="surface-card p-3 p-lg-4">
    <div class="d-flex justify-content-between mb-3"><h2 class="h5 section-title mb-0">Bookings <span class="text-muted-custom fw-normal">(<?= count($appointments) ?> shown, maximum 500)</span></h2></div>
    <?php if (!$appointments): ?><div class="empty-state py-5"><h3 class="h5 section-title">No matching appointments</h3><p class="text-muted-custom mb-0">Change your filters to see other bookings.</p></div>
    <?php else: ?><div class="table-wrap"><table class="table mb-0"><thead><tr><th>Customer</th><th>Service</th><th>Date &amp; time</th><th>Note</th><th>Status</th><th>Update status</th></tr></thead><tbody>
    <?php foreach ($appointments as $appointment): ?><tr>
        <td><div class="fw-semibold"><?= e($appointment['contact_name']) ?></div><div class="small"><?= e($appointment['contact_email']) ?></div><div class="small text-muted-custom"><?= e($appointment['contact_phone']) ?></div></td>
        <td><?= e($appointment['service_name']) ?></td>
        <td><?= e(date('M j, Y', strtotime($appointment['appointment_date']))) ?><div class="small text-muted-custom"><?= e(date('g:i A', strtotime($appointment['appointment_time']))) ?></div></td>
        <td class="small" style="min-width:150px"><?= $appointment['description'] ? nl2br(e($appointment['description'])) : '<span class="text-muted-custom">—</span>' ?></td>
        <td><span class="status-badge <?= e(status_badge_class($appointment['status'])) ?>"><?= e($appointment['status']) ?></span></td>
        <td style="min-width:210px"><form class="d-flex gap-1" method="post" action="<?= e(url('admin/update-appointment.php')) ?>"><?= csrf_field() ?><input type="hidden" name="appointment_id" value="<?= (int) $appointment['id'] ?>"><select class="form-select form-select-sm" name="status" aria-label="New status for appointment <?= (int) $appointment['id'] ?>"><?php foreach ($validStatuses as $option): ?><option value="<?= e($option) ?>" <?= $appointment['status'] === $option ? 'selected' : '' ?>><?= $option === 'Cancelled' ? 'Reject / cancel' : e($option) ?></option><?php endforeach; ?></select><button class="btn btn-sm btn-outline-primary" type="submit">Save</button></form></td>
    </tr><?php endforeach; ?>
    </tbody></table></div><?php endif; ?>
</section>
<?php require __DIR__ . '/../includes/footer.php'; ?>
