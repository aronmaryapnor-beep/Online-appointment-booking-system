<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/config.php';
require_admin();

$search = trim((string) ($_GET['q'] ?? ''));
$statement = db()->prepare(
    'SELECT u.id, u.name, u.email, u.phone, u.created_at,
            COUNT(a.id) AS appointment_count
     FROM users u LEFT JOIN appointments a ON a.user_id = u.id
     WHERE (:search = \'\'
        OR u.name LIKE :name_search
        OR u.email LIKE :email_search
        OR u.phone LIKE :phone_search)
     GROUP BY u.id, u.name, u.email, u.phone, u.created_at
     ORDER BY u.created_at DESC LIMIT 250'
);
$needle = '%' . $search . '%';
$statement->execute([
    'search' => $search,
    'name_search' => $needle,
    'email_search' => $needle,
    'phone_search' => $needle,
]);
$users = $statement->fetchAll();

$pageTitle = 'Manage users';
require __DIR__ . '/../includes/header.php';
?>
<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-end gap-3 mb-4">
    <div><span class="eyebrow">Administration</span><h1 class="h2 page-heading mt-2 mb-1">Registered users</h1><p class="page-subtitle mb-0">Search account details and appointment counts.</p></div>
    <a class="btn btn-outline-primary" href="<?= e(url('admin/dashboard.php')) ?>">← Dashboard</a>
</div>
<section class="surface-card filter-bar mb-3">
    <form class="row g-2 align-items-end" method="get" action="<?= e(url('admin/users.php')) ?>">
        <div class="col-md-6"><label class="form-label mb-1" for="q">Search users</label><input class="form-control" id="q" name="q" value="<?= e($search) ?>" placeholder="Name, email, or phone"></div>
        <div class="col-auto"><button class="btn btn-primary" type="submit">Search</button></div>
        <?php if ($search !== ''): ?><div class="col-auto"><a class="btn btn-link" href="<?= e(url('admin/users.php')) ?>">Clear</a></div><?php endif; ?>
    </form>
</section>
<section class="surface-card p-3 p-lg-4"><div class="d-flex justify-content-between mb-3"><h2 class="h5 section-title mb-0">Users <span class="text-muted-custom fw-normal">(<?= count($users) ?> shown)</span></h2></div>
    <?php if (!$users): ?><div class="empty-state py-5"><h3 class="h5 section-title">No matching users</h3><p class="text-muted-custom mb-0">Try a different name, email, or phone number.</p></div>
    <?php else: ?><div class="table-wrap"><table class="table mb-0"><thead><tr><th>Name</th><th>Email</th><th>Phone</th><th>Appointments</th><th>Joined</th></tr></thead><tbody><?php foreach ($users as $user): ?><tr><td class="fw-semibold"><?= e($user['name']) ?></td><td><?= e($user['email']) ?></td><td><?= e($user['phone']) ?></td><td><?= (int) $user['appointment_count'] ?></td><td><?= e(date('M j, Y', strtotime($user['created_at']))) ?></td></tr><?php endforeach; ?></tbody></table></div><?php endif; ?>
</section>
<?php require __DIR__ . '/../includes/footer.php'; ?>
