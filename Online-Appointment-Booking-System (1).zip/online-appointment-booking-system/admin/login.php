<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/config.php';
if (is_admin()) redirect('admin/dashboard.php');

$error = '';
$email = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $email = strtolower(trim((string) ($_POST['email'] ?? '')));
    $password = (string) ($_POST['password'] ?? '');
    if (!valid_email($email) || $password === '') {
        $error = 'Enter a valid email address and password.';
    } else {
        $statement = db()->prepare('SELECT id, name, email, password_hash FROM admins WHERE email = :email LIMIT 1');
        $statement->execute(['email' => $email]);
        $admin = $statement->fetch();
        if ($admin && password_verify($password, $admin['password_hash'])) {
            session_regenerate_id(true);
            unset($_SESSION['user_id'], $_SESSION['user_name'], $_SESSION['user_email']);
            $_SESSION['admin_id'] = (int) $admin['id'];
            $_SESSION['admin_name'] = $admin['name'];
            flash('success', 'Signed in to the admin dashboard.');
            redirect('admin/dashboard.php');
        }
        $error = 'The email or password is incorrect.';
    }
}

$pageTitle = 'Administrator sign in';
require __DIR__ . '/../includes/header.php';
?>
<section class="auth-wrap">
    <div class="text-center mb-4">
        <div class="auth-mark mx-auto mb-3" aria-hidden="true">A</div>
        <span class="eyebrow">Administrator access</span>
        <h1 class="h2 page-heading mt-2 mb-2">Welcome back</h1>
        <p class="page-subtitle mx-auto mb-0">Manage appointments, users, and services.</p>
    </div>
    <div class="surface-card form-card">
        <?php if ($error !== ''): ?><div class="alert alert-danger" role="alert"><?= e($error) ?></div><?php endif; ?>
        <form method="post" action="<?= e(url('admin/login.php')) ?>" data-validate novalidate>
            <?= csrf_field() ?>
            <div class="mb-3"><label class="form-label" for="email">Admin email</label><input class="form-control" id="email" type="email" name="email" value="<?= e($email) ?>" autocomplete="username" required></div>
            <div class="mb-4"><label class="form-label" for="password">Password</label><input class="form-control" id="password" type="password" name="password" autocomplete="current-password" required></div>
            <button class="btn btn-primary w-100 py-2" type="submit">Sign in as admin</button>
        </form>
        <p class="text-center text-muted-custom small mt-4 mb-0">Admin accounts are created locally with <code>scripts/create-admin.php</code>; there is no public admin registration.</p>
    </div>
</section>
<?php require __DIR__ . '/../includes/footer.php'; ?>
