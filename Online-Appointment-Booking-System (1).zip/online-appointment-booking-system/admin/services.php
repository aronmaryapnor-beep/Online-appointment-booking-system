<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/config.php';
require_admin();
$pdo = db();
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = (string) ($_POST['action'] ?? '');
    if ($action === 'toggle') {
        $serviceId = filter_var($_POST['service_id'] ?? null, FILTER_VALIDATE_INT);
        if (!$serviceId) {
            flash('danger', 'Choose a valid service.');
        } else {
            $toggle = $pdo->prepare('UPDATE services SET is_active = IF(is_active = 1, 0, 1) WHERE id = :id');
            $toggle->execute(['id' => $serviceId]);
            flash('success', 'Service availability updated.');
        }
        redirect('admin/services.php');
    }

    $name = trim((string) ($_POST['name'] ?? ''));
    $description = trim((string) ($_POST['description'] ?? ''));
    $duration = filter_var($_POST['duration_minutes'] ?? null, FILTER_VALIDATE_INT);
    $serviceId = filter_var($_POST['service_id'] ?? null, FILTER_VALIDATE_INT);
    if ($name === '' || strlen($name) > 120) $errors[] = 'Enter a service name of up to 120 characters.';
    if (strlen($description) > 500) $errors[] = 'The description must be 500 characters or fewer.';
    if (!$duration || $duration < 5 || $duration > 480) $errors[] = 'Duration must be between 5 and 480 minutes.';

    if (!$errors) {
        if ($action === 'update' && $serviceId) {
            $active = isset($_POST['is_active']) ? 1 : 0;
            $save = $pdo->prepare('UPDATE services SET name = :name, description = :description, duration_minutes = :duration, is_active = :active WHERE id = :id');
            $save->execute(['name' => $name, 'description' => $description, 'duration' => $duration, 'active' => $active, 'id' => $serviceId]);
            flash('success', 'Service updated.');
            redirect('admin/services.php');
        }
        if ($action === 'create') {
            $save = $pdo->prepare('INSERT INTO services (name, description, duration_minutes) VALUES (:name, :description, :duration)');
            $save->execute(['name' => $name, 'description' => $description, 'duration' => $duration]);
            flash('success', 'Service added.');
            redirect('admin/services.php');
        }
        $errors[] = 'Choose a valid service action.';
    }
}

$editId = filter_input(INPUT_GET, 'edit', FILTER_VALIDATE_INT);
$editing = null;
if ($editId) {
    $getService = $pdo->prepare('SELECT * FROM services WHERE id = :id');
    $getService->execute(['id' => $editId]);
    $editing = $getService->fetch() ?: null;
}
$services = $pdo->query('SELECT * FROM services ORDER BY is_active DESC, name')->fetchAll();
$pageTitle = 'Manage services';
require __DIR__ . '/../includes/header.php';
?>
<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-end gap-3 mb-4">
    <div><span class="eyebrow">Administration</span><h1 class="h2 page-heading mt-2 mb-1">Manage services</h1><p class="page-subtitle mb-0">Add, edit, or archive services offered to customers.</p></div>
    <a class="btn btn-outline-primary" href="<?= e(url('admin/dashboard.php')) ?>">← Dashboard</a>
</div>
<div class="row g-3 g-lg-4">
    <div class="col-lg-5"><section class="surface-card form-card">
        <h2 class="h5 section-title mb-3"><?= $editing ? 'Edit service' : 'Add a service' ?></h2>
        <?php if ($errors): ?><div class="alert alert-danger" role="alert"><ul class="mb-0"><?php foreach ($errors as $error): ?><li><?= e($error) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
        <form method="post" action="<?= e(url('admin/services.php' . ($editing ? '?edit=' . (int) $editing['id'] : ''))) ?>" data-validate novalidate>
            <?= csrf_field() ?><input type="hidden" name="action" value="<?= $editing ? 'update' : 'create' ?>"><?php if ($editing): ?><input type="hidden" name="service_id" value="<?= (int) $editing['id'] ?>"><?php endif; ?>
            <div class="mb-3"><label class="form-label" for="name">Service name</label><input class="form-control" id="name" name="name" maxlength="120" value="<?= e($editing['name'] ?? '') ?>" required></div>
            <div class="mb-3"><label class="form-label" for="description">Description</label><textarea class="form-control" id="description" name="description" maxlength="500"><?= e($editing['description'] ?? '') ?></textarea></div>
            <div class="mb-3"><label class="form-label" for="duration_minutes">Duration in minutes</label><input class="form-control" id="duration_minutes" type="number" name="duration_minutes" min="5" max="480" step="5" value="<?= (int) ($editing['duration_minutes'] ?? 30) ?>" required></div>
            <?php if ($editing): ?><div class="form-check mb-3"><input class="form-check-input" type="checkbox" name="is_active" id="is_active" <?= (int) $editing['is_active'] === 1 ? 'checked' : '' ?>><label class="form-check-label" for="is_active">Available for new bookings</label></div><?php endif; ?>
            <div class="d-flex gap-2"><button class="btn btn-primary" type="submit"><?= $editing ? 'Save service' : 'Add service' ?></button><?php if ($editing): ?><a class="btn btn-outline-secondary" href="<?= e(url('admin/services.php')) ?>">Cancel</a><?php endif; ?></div>
        </form>
    </section></div>
    <div class="col-lg-7"><section class="surface-card p-3 p-lg-4 h-100">
        <h2 class="h5 section-title mb-3">Service list</h2>
        <?php if (!$services): ?><div class="empty-state py-5"><h3 class="h5 section-title">No services added</h3><p class="text-muted-custom mb-0">Add the first service using the form.</p></div>
        <?php else: ?><div class="table-wrap"><table class="table mb-0"><thead><tr><th>Service</th><th>Duration</th><th>Availability</th><th></th></tr></thead><tbody><?php foreach ($services as $service): ?><tr><td><div class="fw-semibold"><?= e($service['name']) ?></div><div class="small text-muted-custom"><?= e($service['description']) ?></div></td><td><?= (int) $service['duration_minutes'] ?> min</td><td><?= (int) $service['is_active'] === 1 ? '<span class="status-badge status-confirmed">Active</span>' : '<span class="status-badge status-cancelled">Archived</span>' ?></td><td class="text-end text-nowrap"><a class="btn btn-sm btn-outline-primary" href="<?= e(url('admin/services.php?edit=' . (int) $service['id'])) ?>">Edit</a><form class="d-inline" method="post" action="<?= e(url('admin/services.php')) ?>"><?= csrf_field() ?><input type="hidden" name="action" value="toggle"><input type="hidden" name="service_id" value="<?= (int) $service['id'] ?>"><button class="btn btn-sm btn-outline-secondary" type="submit"><?= (int) $service['is_active'] === 1 ? 'Archive' : 'Activate' ?></button></form></td></tr><?php endforeach; ?></tbody></table></div><?php endif; ?>
        <p class="small text-muted-custom mt-3 mb-0">Services with appointment history are archived rather than deleted so existing records remain intact.</p>
    </section></div>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
