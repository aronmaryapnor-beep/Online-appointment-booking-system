<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/config.php';
require_admin();
$pdo = db();

$counts = $pdo->query(
    "SELECT
        COUNT(*) AS total,
        SUM(status = 'Pending') AS pending,
        SUM(status = 'Confirmed') AS confirmed,
        SUM(status = 'Completed') AS completed,
        SUM(status = 'Cancelled') AS cancelled
     FROM appointments"
)->fetch() ?: [];
$userCount = (int) $pdo->query('SELECT COUNT(*) FROM users')->fetchColumn();
$serviceCount = (int) $pdo->query('SELECT COUNT(*) FROM services WHERE is_active = 1')->fetchColumn();
$todayStatement = $pdo->query(
    "SELECT a.*, s.name AS service_name
     FROM appointments a JOIN services s ON s.id = a.service_id
     WHERE a.appointment_date = CURDATE() AND a.status IN ('Pending', 'Confirmed')
     ORDER BY a.appointment_time LIMIT 6"
);
$todayAppointments = $todayStatement->fetchAll();

$pageTitle = 'Admin dashboard';
require __DIR__ . '/../includes/header.php';
?>
<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-end gap-3 mb-4">
    <div><span class="admin-label">Administration</span><h1 class="h2 page-heading mt-2 mb-1">Good day, <?= e(explode(' ', (string) $_SESSION['admin_name'])[0]) ?>.</h1><p class="page-subtitle mb-0">Your appointment operations at a glance.</p></div>
    <div class="d-flex gap-2"><a class="btn btn-outline-primary" href="<?= e(url('admin/users.php')) ?>">View users</a><a class="btn btn-primary" href="<?= e(url('admin/appointments.php')) ?>">Manage appointments</a></div>
</div>
<section class="row g-3 mb-4" aria-label="Admin summary">
    <div class="col-6 col-lg-3"><div class="surface-card stat-card h-100"><div class="stat-value"><?= (int) ($counts['pending'] ?? 0) ?></div><div class="stat-label">Pending requests</div></div></div>
    <div class="col-6 col-lg-3"><div class="surface-card stat-card h-100"><div class="stat-value"><?= (int) ($counts['confirmed'] ?? 0) ?></div><div class="stat-label">Confirmed</div></div></div>
    <div class="col-6 col-lg-3"><div class="surface-card stat-card h-100"><div class="stat-value"><?= $userCount ?></div><div class="stat-label">Registered users</div></div></div>
    <div class="col-6 col-lg-3"><div class="surface-card stat-card h-100"><div class="stat-value"><?= $serviceCount ?></div><div class="stat-label">Active services</div></div></div>
</section>
<section class="surface-card p-3 p-lg-4">
    <div class="d-flex flex-column flex-sm-row justify-content-between gap-2 mb-3">
        <div><span class="eyebrow">Today</span><h2 class="h4 section-title mt-2 mb-0">Upcoming appointments</h2></div>
        <a class="btn btn-sm btn-outline-primary align-self-sm-center" href="<?= e(url('admin/appointments.php?date=' . date('Y-m-d'))) ?>">See today’s schedule</a>
    </div>
    <?php if (!$todayAppointments): ?><div class="empty-state py-5"><div class="empty-icon" aria-hidden="true">◷</div><h3 class="h5 section-title">No active appointments today</h3><p class="text-muted-custom mb-0">New requests will show here as customers book.</p></div>
    <?php else: ?><div class="table-wrap"><table class="table mb-0"><thead><tr><th>Time</th><th>Customer</th><th>Service</th><th>Status</th></tr></thead><tbody><?php foreach ($todayAppointments as $appointment): ?><tr><td class="fw-semibold"><?= e(date('g:i A', strtotime($appointment['appointment_time']))) ?></td><td><?= e($appointment['contact_name']) ?><div class="small text-muted-custom"><?= e($appointment['contact_email']) ?></div></td><td><?= e($appointment['service_name']) ?></td><td><span class="status-badge <?= e(status_badge_class($appointment['status'])) ?>"><?= e($appointment['status']) ?></span></td></tr><?php endforeach; ?></tbody></table></div><?php endif; ?>
</section>
<div class="row g-3 mt-1">
    <div class="col-md-6"><a class="surface-card d-flex align-items-center justify-content-between p-4 text-decoration-none" href="<?= e(url('admin/appointments.php')) ?>"><div><span class="eyebrow">Bookings</span><h2 class="h5 section-title mt-2 mb-0">Search &amp; manage appointments</h2></div><span class="fs-3 text-primary" aria-hidden="true">→</span></a></div>
    <div class="col-md-6"><a class="surface-card d-flex align-items-center justify-content-between p-4 text-decoration-none" href="<?= e(url('admin/services.php')) ?>"><div><span class="eyebrow">Catalog</span><h2 class="h5 section-title mt-2 mb-0">Manage offered services</h2></div><span class="fs-3 text-primary" aria-hidden="true">→</span></a></div>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
