<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/config.php';
require_admin();
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    header('Allow: POST');
    exit('Use the appointment status form.');
}
verify_csrf();
$appointmentId = filter_input(INPUT_POST, 'appointment_id', FILTER_VALIDATE_INT);
$status = (string) ($_POST['status'] ?? '');
$allowed = ['Pending', 'Confirmed', 'Completed', 'Cancelled'];
if (!$appointmentId || !in_array($status, $allowed, true)) {
    flash('danger', 'Choose a valid appointment and status.');
    redirect('admin/appointments.php');
}
try {
    $statement = db()->prepare('UPDATE appointments SET status = :status WHERE id = :id');
    $statement->execute(['status' => $status, 'id' => $appointmentId]);
    flash('success', 'Appointment status updated to ' . $status . '.');
} catch (PDOException $exception) {
    if ($exception->getCode() === '23000') {
        flash('danger', 'That appointment cannot be confirmed because another active booking already uses that time slot.');
    } else {
        throw $exception;
    }
}
redirect('admin/appointments.php');
