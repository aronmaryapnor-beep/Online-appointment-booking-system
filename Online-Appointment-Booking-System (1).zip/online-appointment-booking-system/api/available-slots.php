<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/config.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

if (!current_user()) {
    http_response_code(401);
    echo json_encode(['message' => 'Sign in to view available appointment times.']);
    exit;
}

$date = trim((string) ($_GET['date'] ?? ''));
if (!valid_date($date) || $date < date('Y-m-d')) {
    http_response_code(422);
    echo json_encode(['message' => 'Choose today or a future date.']);
    exit;
}

$statement = db()->prepare(
    "SELECT TIME_FORMAT(appointment_time, '%H:%i') AS booked_time
     FROM appointments
     WHERE appointment_date = :appointment_date
       AND status IN ('Pending', 'Confirmed')"
);
$params = ['appointment_date' => $date];
$excludeId = filter_input(INPUT_GET, 'exclude_id', FILTER_VALIDATE_INT);
if ($excludeId) {
    $ownerCheck = db()->prepare(
        "SELECT id FROM appointments
         WHERE id = :id AND user_id = :user_id
           AND status IN ('Pending', 'Confirmed')"
    );
    $ownerCheck->execute(['id' => $excludeId, 'user_id' => current_user()['id']]);
    if ($ownerCheck->fetchColumn()) {
        $statement = db()->prepare(
            "SELECT TIME_FORMAT(appointment_time, '%H:%i') AS booked_time
             FROM appointments
             WHERE appointment_date = :appointment_date
               AND status IN ('Pending', 'Confirmed') AND id <> :exclude_id"
        );
        $params['exclude_id'] = $excludeId;
    }
}
$statement->execute($params);
$booked = array_fill_keys(array_column($statement->fetchAll(), 'booked_time'), true);
$now = new DateTimeImmutable();
$slots = [];
foreach (allowed_time_slots() as $time) {
    if (isset($booked[$time])) {
        continue;
    }
    if ($date === date('Y-m-d') && $time <= $now->format('H:i')) {
        continue;
    }
    $slots[] = ['value' => $time, 'label' => date('g:i A', strtotime($time))];
}

echo json_encode(['slots' => $slots], JSON_UNESCAPED_SLASHES);
