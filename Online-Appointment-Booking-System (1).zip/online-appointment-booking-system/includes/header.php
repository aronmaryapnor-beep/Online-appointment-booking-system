<?php
$pageTitle = $pageTitle ?? APP_NAME;
$activePage = $activePage ?? '';
$flashes = get_flashes();
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#132b4f">
    <title><?= e($pageTitle) ?> · <?= e(APP_NAME) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href="<?= e(url('assets/css/style.css')) ?>" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark app-navbar">
    <div class="container">
        <a class="navbar-brand d-flex align-items-center gap-2" href="<?= e(url('index.php')) ?>">
            <span class="brand-mark">A</span><span>appointmently</span>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav" aria-controls="mainNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="mainNav">
            <ul class="navbar-nav ms-auto align-items-lg-center gap-lg-2">
                <li class="nav-item"><a class="nav-link <?= $activePage === 'home' ? 'active' : '' ?>" href="<?= e(url('index.php')) ?>">Home</a></li>
                <?php if (current_user()): ?>
                    <li class="nav-item"><a class="nav-link <?= $activePage === 'dashboard' ? 'active' : '' ?>" href="<?= e(url('dashboard.php')) ?>">Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link <?= $activePage === 'appointments' ? 'active' : '' ?>" href="<?= e(url('my-appointments.php')) ?>">My appointments</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?= e(url('book-appointment.php')) ?>">Book a visit</a></li>
                    <li class="nav-item"><span class="nav-user">Hi, <?= e(explode(' ', (string) $_SESSION['user_name'])[0]) ?></span></li>
                    <li class="nav-item"><form method="post" action="<?= e(url('logout.php')) ?>"><?= csrf_field() ?><button class="btn btn-sm btn-outline-light rounded-pill px-3" type="submit">Sign out</button></form></li>
                <?php elseif (is_admin()): ?>
                    <li class="nav-item"><a class="nav-link" href="<?= e(url('admin/dashboard.php')) ?>">Admin dashboard</a></li>
                    <li class="nav-item"><form method="post" action="<?= e(url('logout.php')) ?>"><?= csrf_field() ?><button class="btn btn-sm btn-outline-light rounded-pill px-3" type="submit">Sign out</button></form></li>
                <?php else: ?>
                    <li class="nav-item"><a class="nav-link" href="<?= e(url('admin/login.php')) ?>">Admin</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?= e(url('login.php')) ?>">Sign in</a></li>
                    <li class="nav-item"><a class="btn btn-sm btn-light rounded-pill px-3" href="<?= e(url('register.php')) ?>">Create account</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>
<main class="app-main">
    <div class="container">
        <?php foreach ($flashes as $item): ?>
            <div class="alert alert-<?= e($item['type']) ?> alert-dismissible fade show app-alert" role="alert">
                <?= e($item['message']) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endforeach; ?>
