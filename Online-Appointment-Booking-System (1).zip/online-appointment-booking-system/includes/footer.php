    </div>
</main>
<footer class="app-footer">
    <div class="container d-flex flex-column flex-md-row justify-content-between gap-2">
        <span>© <?= date('Y') ?> Appointmently · College project</span>
        <span>Simple scheduling, made more human.</span>
    </div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
<script src="<?= e(url('assets/js/script.js')) ?>" defer></script>
</body>
</html>
