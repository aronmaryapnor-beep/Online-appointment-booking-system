<?php
declare(strict_types=1);

function e(mixed $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function url(string $path = ''): string
{
    return APP_BASE_PATH . '/' . ltrim($path, '/');
}

function redirect(string $path): never
{
    header('Location: ' . url($path));
    exit;
}

function csrf_token(): string
{
    if (empty($_SESSION['_csrf_token'])) {
        $_SESSION['_csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['_csrf_token'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="_csrf" value="' . e(csrf_token()) . '">';
}

function verify_csrf(): void
{
    $submitted = $_POST['_csrf'] ?? '';
    if (!is_string($submitted) || !hash_equals(csrf_token(), $submitted)) {
        http_response_code(419);
        exit('Your session has expired. Go back, refresh the page, and try again.');
    }
}

function flash(string $type, string $message): void
{
    $_SESSION['_flash'][] = ['type' => $type, 'message' => $message];
}

function get_flashes(): array
{
    $messages = $_SESSION['_flash'] ?? [];
    unset($_SESSION['_flash']);
    return is_array($messages) ? $messages : [];
}

function current_user(): ?array
{
    return isset($_SESSION['user_id'], $_SESSION['user_name'], $_SESSION['user_email'])
        ? ['id' => (int) $_SESSION['user_id'], 'name' => $_SESSION['user_name'], 'email' => $_SESSION['user_email']]
        : null;
}

function is_admin(): bool
{
    return isset($_SESSION['admin_id'], $_SESSION['admin_name']);
}

function require_user(): array
{
    $user = current_user();
    if ($user === null) {
        flash('warning', 'Please sign in to continue.');
        redirect('login.php');
    }
    return $user;
}

function require_admin(): void
{
    if (!is_admin()) {
        flash('warning', 'Please sign in as an administrator.');
        redirect('admin/login.php');
    }
}

function valid_email(string $email): bool
{
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

function valid_phone(string $phone): bool
{
    return preg_match('/^[0-9+().\-\s]{7,24}$/', $phone) === 1
        && preg_match_all('/\d/', $phone) >= 7;
}

function valid_date(string $date): bool
{
    $parsed = DateTimeImmutable::createFromFormat('!Y-m-d', $date);
    return $parsed !== false && $parsed->format('Y-m-d') === $date;
}

function allowed_time_slots(): array
{
    $slots = [];
    for ($minutes = 9 * 60; $minutes < 17 * 60; $minutes += 30) {
        $slots[] = sprintf('%02d:%02d', intdiv($minutes, 60), $minutes % 60);
    }
    return $slots;
}

function status_badge_class(string $status): string
{
    return match ($status) {
        'Confirmed' => 'status-confirmed',
        'Completed' => 'status-completed',
        'Cancelled' => 'status-cancelled',
        default => 'status-pending',
    };
}

function appointment_by_id_for_user(PDO $pdo, int $appointmentId, int $userId): ?array
{
    $stmt = $pdo->prepare(
        'SELECT a.*, s.name AS service_name
         FROM appointments a JOIN services s ON s.id = a.service_id
         WHERE a.id = :id AND a.user_id = :user_id LIMIT 1'
    );
    $stmt->execute(['id' => $appointmentId, 'user_id' => $userId]);
    $appointment = $stmt->fetch();
    return $appointment ?: null;
}
