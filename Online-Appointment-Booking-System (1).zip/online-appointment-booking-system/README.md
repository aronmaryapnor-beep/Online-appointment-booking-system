# Online Appointment Booking System

A responsive PHP and MySQL application for requesting and managing appointments. Customers can register, see available time slots, book and update appointments, and track their status. Administrators can review customers and bookings, manage appointment status, and maintain the service list.

## Features

- Customer registration, sign-in, sign-out, and session-protected pages
- Separate administrator sign-in and role-specific dashboard
- Passwords stored as PHP `password_hash()` hashes
- Appointment booking with name, email, phone, service, date, time slot, and an optional description
- Available time slots refreshed for the selected date
- A database unique constraint prevents two active bookings from claiming the same date and time, including simultaneous booking attempts
- A cancelled booking releases its slot
- Customers can view, filter, edit, and cancel their own appointments
- Editing a confirmed appointment returns it to Pending for administrator review
- Administrator appointment search and filters for status and date
- Administrator actions to confirm, complete, or reject/cancel a booking
- Administrator user search and appointment counts
- Administrator service creation, editing, activation, and archiving
- Browser-side and server-side validation, CSRF protection, PDO prepared statements, and HTML escaping
- Responsive layout using Bootstrap 5 and custom CSS

The statuses used are **Pending**, **Confirmed**, **Completed**, and **Cancelled**. Rejecting an appointment sets its status to **Cancelled**, because the required database status set does not include a separate Rejected status.

## Technologies

- Frontend: HTML5, CSS3, Bootstrap 5, and JavaScript
- Backend: PHP 8.1 or newer (8.2 recommended)
- Database: MySQL 8.0+ or a recent MariaDB release; PDO MySQL extension enabled
- Local development: XAMPP and phpMyAdmin
- Version control: Git and GitHub

Bootstrap is loaded from jsDelivr, so an internet connection is required for its styling and responsive navigation. The custom CSS and JavaScript are included in this project.

## Folder structure

```text
online-appointment-booking-system/
├── index.php
├── register.php
├── login.php
├── logout.php
├── dashboard.php
├── book-appointment.php
├── my-appointments.php
├── edit-appointment.php
├── cancel-appointment.php
├── api/
│   └── available-slots.php
├── admin/
│   ├── login.php
│   ├── dashboard.php
│   ├── appointments.php
│   ├── update-appointment.php
│   ├── users.php
│   └── services.php
├── config/
│   ├── config.php
│   └── config.local.example.php
├── includes/
│   ├── helpers.php
│   ├── header.php
│   └── footer.php
├── assets/
│   ├── css/
│   │   └── style.css
│   └── js/
│       └── script.js
├── scripts/
│   └── create-admin.php
├── database.sql
├── README.md
└── .gitignore
```

## Requirements

- XAMPP with Apache and MySQL/MariaDB, or another local PHP/MySQL setup
- PHP 8.1+ with the `pdo_mysql` extension enabled
- A modern browser
- Git (optional, for the GitHub steps)

## Run locally with XAMPP and phpMyAdmin

1. **Download and extract the ZIP.** Keep the project folder named `online-appointment-booking-system`, or choose a shorter folder name and use that name in the URL.
2. **Copy the project into XAMPP's web root.** For a standard Windows installation, copy the folder into `C:\xampp\htdocs\`. On macOS or Linux, use the `htdocs` directory in your XAMPP installation.
3. **Start Apache and MySQL.** Open the XAMPP Control Panel and start both services.
4. **Import the database.**
   - Open `http://localhost/phpmyadmin/`.
   - Select **Import** in the top menu.
   - Choose `database.sql` from the project folder and press **Import** (or **Go**).
   - The script creates `appointment_booking_system`, its four tables, indexes, foreign keys, and three example services.
   - **Important:** importing this script again drops and recreates these project tables. Back up any data you want to keep before re-importing.
5. **Configure the database.**
   - Copy `config/config.local.example.php` to `config/config.local.php`.
   - Open `config/config.local.php` and set `DB_HOST`, `DB_PORT`, `DB_NAME`, `DB_USER`, and `DB_PASS` to match your local MySQL account.
   - A standard fresh XAMPP installation often uses `root` with a blank password. If yours has a password, enter it only in `config.local.php`.
   - Leave `APP_BASE_PATH` blank for automatic detection when the project is directly inside `htdocs`. If you use a custom web-server rewrite or mount point, set it to the app's URL prefix, for example `/online-appointment-booking-system`.
   - `config.local.php` is excluded from Git. Never commit real credentials.
6. **Create an administrator account.**
   - Open a terminal in the project directory.
   - Run `php scripts/create-admin.php "Admin Name" admin@example.com`.
   - Enter and confirm a password when prompted. Use a password at least 8 characters long.
   - This script creates an admin in the database; it does not make a default admin login or put a password in the source code.
7. **Open the app.** Visit `http://localhost/online-appointment-booking-system/` in your browser. Use the actual folder name if you changed it.
8. Use **Create account** for a customer account, or choose **Admin** in the navigation to sign in with the administrator account created in step 6.

### Optional: run with PHP's built-in server

With MySQL running and the database configured, open a terminal in the project folder and run:

```bash
php -S 127.0.0.1:8000 -t .
```

Then visit `http://127.0.0.1:8000/`. Stop the server with `Ctrl+C`.

## How to test the main flows

1. Register a customer account and verify that the dashboard opens.
2. Sign out, then sign in again with that account.
3. Open **Book an appointment**, choose a service and future date, and select one of the available times. Submit the request; it should appear with **Pending** status.
4. Try creating a second appointment at the same date and time from another account. The slot should no longer appear; if two requests race, the database constraint rejects the duplicate.
5. In **My appointments**, edit a pending booking to a different available time. The updated booking is saved as **Pending**.
6. Cancel an active booking. Its status becomes **Cancelled** and that time can be booked again.
7. Sign in at **Admin**. Search and filter appointments, confirm a pending request, mark it Completed, or reject it using **Reject / cancel**.
8. In the admin dashboard, review registered users. Open **Manage services** to edit a service or archive/reactivate it. Archived services remain on previous appointments but cannot be selected for new ones.
9. Sign out from both user and admin accounts and verify protected pages send you back to sign-in.

There are no preconfigured administrator credentials or demo passwords in this project. The setup command above creates the first administrator using a password you choose.

## Upload to GitHub

1. Install Git and open a terminal in the project folder.
2. Confirm `config/config.local.php` is not staged. It is ignored by the included `.gitignore`.
3. Initialize and commit the project:

   ```bash
   git init
   git add .
   git status
   git commit -m "Add online appointment booking system"
   ```

4. Create an empty repository on GitHub. Do not add a README if you already intend to push this project README.
5. Add the repository URL and push:

   ```bash
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
   git push -u origin main
   ```

Replace the example GitHub URL with your own repository URL. Never push database passwords, private configuration files, or production customer data.

## Security notes

- User and admin passwords are hashed with `password_hash()` and checked with `password_verify()`.
- All database values are sent through PDO prepared statements.
- Mutating forms include CSRF tokens; session IDs are regenerated after login.
- The active-slot unique key covers Pending and Confirmed appointments. Cancelled and Completed appointments do not reserve that time.
- This is an educational local project. Before using it with real customers, deploy only over HTTPS, use a dedicated database account with a strong password, review privacy and data-retention requirements, and add operational protections such as login rate limiting and backups.

## Common problems

| Problem | What to check |
| --- | --- |
| “Unable to connect to the database” | Start MySQL in XAMPP, confirm the database name and port, and check `config/config.local.php`. |
| `could not find driver` or `PDO driver is not available` | Enable PHP's `pdo_mysql` extension in the PHP configuration used by Apache, then restart Apache. |
| phpMyAdmin says the database already exists | That is fine. Import `database.sql`; note that it drops and recreates the project's four tables. Back up data first if needed. |
| `Table ... doesn't exist` | Import `database.sql` into phpMyAdmin and confirm `appointment_booking_system` is selected/created. |
| A duplicate-slot error appears | Another active appointment has already claimed that date and time. Choose a different slot. |
| Admin login does not work | Create an admin with `php scripts/create-admin.php "Admin Name" admin@example.com`. There is no default admin password. |
| Page links open at the wrong URL | Keep the project folder in the server's document root and check `APP_BASE_PATH` in `config/config.local.php`. |
| Styles or responsive menu do not load | Check your internet connection; Bootstrap 5 is loaded from jsDelivr. The local CSS and JavaScript are under `assets/`. |
| “Your session has expired” | Refresh the page and submit the form again. Keep cookies enabled and check the computer's date/time. |

## Database overview

- `users`: customer profile and password hash
- `admins`: administrator profile and password hash, created by the CLI setup script
- `services`: service description, duration, and active/archive state
- `appointments`: contact snapshot, user/service relationships, requested date/time, description, and status

The appointment's `active_slot_key` is a generated column with a unique index. It is non-null only for Pending and Confirmed appointments, enforcing one active booking per date/time at the database level.
