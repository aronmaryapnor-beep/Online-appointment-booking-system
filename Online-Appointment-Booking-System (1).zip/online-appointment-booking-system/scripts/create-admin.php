<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/config.php';

if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    exit("Run this script from the command line.\n");
}

$name = trim((string) ($argv[1] ?? ''));
$email = strtolower(trim((string) ($argv[2] ?? '')));
if ($name === '' || strlen($name) > 100 || !valid_email($email) || strlen($email) > 190) {
    fwrite(STDERR, "Usage: php scripts/create-admin.php \"Admin Name\" admin@example.com\n");
    exit(2);
}
fwrite(STDOUT, "New password (8–72 characters): ");
$password = trim((string) fgets(STDIN));
fwrite(STDOUT, "Confirm password: ");
$confirmation = trim((string) fgets(STDIN));
if (strlen($password) < 8 || strlen($password) > 72 || $password !== $confirmation) {
    fwrite(STDERR, "Passwords must match and be 8–72 characters long.\n");
    exit(2);
}

try {
    $statement = db()->prepare(
        'INSERT INTO admins (name, email, password_hash) VALUES (:name, :email, :password_hash)'
    );
    $statement->execute([
        'name' => $name,
        'email' => $email,
        'password_hash' => password_hash($password, PASSWORD_DEFAULT),
    ]);
    fwrite(STDOUT, "Administrator account created for {$email}.\n");
} catch (PDOException $exception) {
    if ($exception->getCode() === '23000') {
        fwrite(STDERR, "An administrator with that email already exists.\n");
        exit(1);
    }
    throw $exception;
}
