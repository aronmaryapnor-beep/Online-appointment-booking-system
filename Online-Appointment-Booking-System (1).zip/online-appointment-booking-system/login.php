<?php
declare(strict_types=1);
require_once __DIR__ . '/config/config.php';

if (current_user()) {
    redirect('dashboard.php');
}

$error = '';
$email = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $email = strtolower(trim((string) ($_POST['email'] ?? '')));
    $password = (string) ($_POST['password'] ?? '');

    if (!valid_email($email) || $password === '') {
        $error = 'Enter a valid email address and password.';
    } else {
        $statement = db()->prepare('SELECT id, name, email, password_hash FROM users WHERE email = :email LIMIT 1');
        $statement->execute(['email' => $email]);
        $user = $statement->fetch();
        if ($user && password_verify($password, $user['password_hash'])) {
            session_regenerate_id(true);
            unset($_SESSION['admin_id'], $_SESSION['admin_name']);
            $_SESSION['user_id'] = (int) $user['id'];
            $_SESSION['user_name'] = $user['name'];
            $_SESSION['user_email'] = $user['email'];
            flash('success', 'Welcome back, ' . $user['name'] . '.');
            redirect('dashboard.php');
        }
        $error = 'The email or password is incorrect.';
    }
}

$pageTitle = 'Sign in';
require __DIR__ . '/includes/header.php';
?>
<section class="auth-wrap">
    <div class="text-center mb-4">
        <div class="auth-mark mx-auto mb-3" aria-hidden="true">A</div>
        <span class="eyebrow">Good to see you again</span>
        <h1 class="h2 page-heading mt-2 mb-2">Sign in</h1>
        <p class="page-subtitle mx-auto mb-0">Your upcoming visits and appointment history are waiting.</p>
    </div>
    <div class="surface-card form-card">
        <?php if ($error !== ''): ?><div class="alert alert-danger" role="alert"><?= e($error) ?></div><?php endif; ?>
        <form method="post" action="<?= e(url('login.php')) ?>" data-validate novalidate>
            <?= csrf_field() ?>
            <div class="mb-3"><label class="form-label" for="email">Email address</label><input class="form-control" id="email" type="email" name="email" value="<?= e($email) ?>" autocomplete="email" required></div>
            <div class="mb-4"><label class="form-label" for="password">Password</label><input class="form-control" id="password" type="password" name="password" autocomplete="current-password" required></div>
            <button class="btn btn-primary w-100 py-2" type="submit">Sign in to your account</button>
        </form>
        <p class="text-center text-muted-custom mt-4 mb-0">New here? <a href="<?= e(url('register.php')) ?>">Create an account</a></p>
    </div>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>
