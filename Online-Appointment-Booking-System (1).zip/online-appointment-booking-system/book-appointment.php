<?php
declare(strict_types=1);
require_once __DIR__ . '/config/config.php';
$user = require_user();
$pdo = db();

$services = $pdo->query('SELECT id, name, description, duration_minutes FROM services WHERE is_active = 1 ORDER BY name')->fetchAll();
if (!$services) {
    flash('warning', 'There are no active services right now. Please check back later.');
    redirect('dashboard.php');
}

$errors = [];
$contactName = $user['name'];
$contactEmail = $user['email'];
$contactPhone = '';
$serviceId = '';
$appointmentDate = '';
$description = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $contactName = trim((string) ($_POST['contact_name'] ?? ''));
    $contactEmail = strtolower(trim((string) ($_POST['contact_email'] ?? '')));
    $contactPhone = trim((string) ($_POST['contact_phone'] ?? ''));
    $serviceId = (string) ($_POST['service_id'] ?? '');
    $appointmentDate = trim((string) ($_POST['appointment_date'] ?? ''));
    $appointmentTime = trim((string) ($_POST['appointment_time'] ?? ''));
    $description = trim((string) ($_POST['description'] ?? ''));

    if ($contactName === '' || strlen($contactName) > 100) $errors[] = 'Enter your full name (up to 100 characters).';
    if (!valid_email($contactEmail) || strlen($contactEmail) > 190) $errors[] = 'Enter a valid email address.';
    if (!valid_phone($contactPhone)) $errors[] = 'Enter a valid phone number with at least 7 digits.';
    if (!ctype_digit($serviceId) || !in_array((int) $serviceId, array_map(static fn($service) => (int) $service['id'], $services), true)) $errors[] = 'Choose an active service.';
    if (!valid_date($appointmentDate) || $appointmentDate < date('Y-m-d')) $errors[] = 'Choose today or a future appointment date.';
    if (!in_array($appointmentTime, allowed_time_slots(), true)) $errors[] = 'Choose an available appointment time.';
    if (strlen($description) > 2000) $errors[] = 'The description must be 2,000 characters or fewer.';
    if (!$errors && $appointmentDate === date('Y-m-d') && $appointmentTime <= date('H:i')) $errors[] = 'Choose a later time for today.';

    if (!$errors) {
        try {
            $insert = $pdo->prepare(
                "INSERT INTO appointments
                    (user_id, service_id, contact_name, contact_email, contact_phone,
                     appointment_date, appointment_time, description, status)
                 VALUES
                    (:user_id, :service_id, :contact_name, :contact_email, :contact_phone,
                     :appointment_date, :appointment_time, :description, 'Pending')"
            );
            $insert->execute([
                'user_id' => $user['id'],
                'service_id' => (int) $serviceId,
                'contact_name' => $contactName,
                'contact_email' => $contactEmail,
                'contact_phone' => $contactPhone,
                'appointment_date' => $appointmentDate,
                'appointment_time' => $appointmentTime,
                'description' => $description !== '' ? $description : null,
            ]);
            flash('success', 'Your appointment request has been submitted and is pending confirmation.');
            redirect('my-appointments.php');
        } catch (PDOException $exception) {
            if ($exception->getCode() === '23000') {
                $errors[] = 'That time was just booked. Please choose another available slot.';
            } else {
                throw $exception;
            }
        }
    }
}

$pageTitle = 'Book an appointment';
require __DIR__ . '/includes/header.php';
?>
<div class="form-shell">
    <div class="mb-4"><span class="eyebrow">Let’s find a time</span><h1 class="h2 page-heading mt-2 mb-2">Book an appointment</h1><p class="page-subtitle mb-0">Choose a service and an open slot. Your request will be marked pending until an administrator confirms it.</p></div>
    <div class="surface-card form-card">
        <?php if ($errors): ?><div class="alert alert-danger" role="alert"><ul class="mb-0"><?php foreach ($errors as $error): ?><li><?= e($error) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
        <form method="post" action="<?= e(url('book-appointment.php')) ?>" data-booking-form data-availability-url="<?= e(url('api/available-slots.php')) ?>" data-validate novalidate>
            <?= csrf_field() ?>
            <div class="row g-3">
                <div class="col-md-6"><label class="form-label" for="contact_name">Your name</label><input class="form-control" id="contact_name" name="contact_name" value="<?= e($contactName) ?>" maxlength="100" autocomplete="name" required></div>
                <div class="col-md-6"><label class="form-label" for="contact_email">Email address</label><input class="form-control" id="contact_email" type="email" name="contact_email" value="<?= e($contactEmail) ?>" maxlength="190" autocomplete="email" required></div>
                <div class="col-md-6"><label class="form-label" for="contact_phone">Phone number</label><input class="form-control" id="contact_phone" name="contact_phone" value="<?= e($contactPhone) ?>" maxlength="24" pattern="[0-9+().\-\s]{7,24}" autocomplete="tel" required></div>
                <div class="col-md-6"><label class="form-label" for="service_id">Service</label><select class="form-select" id="service_id" name="service_id" required><option value="">Select a service</option><?php foreach ($services as $service): ?><option value="<?= (int) $service['id'] ?>" <?= (string) $service['id'] === $serviceId ? 'selected' : '' ?>><?= e($service['name']) ?> · <?= (int) $service['duration_minutes'] ?> min</option><?php endforeach; ?></select></div>
                <div class="col-md-6"><label class="form-label" for="appointment_date">Appointment date</label><input class="form-control" id="appointment_date" type="date" name="appointment_date" min="<?= e(date('Y-m-d')) ?>" value="<?= e($appointmentDate) ?>" required></div>
                <div class="col-12"><label class="form-label d-block">Available time slots</label><div class="slot-list mb-2" data-slot-list aria-live="polite"><div class="slot-empty">Choose a date to see available times.</div></div><input type="hidden" name="appointment_time" value=""><div class="form-text">Times are shown in the clinic’s local time.</div></div>
                <div class="col-12"><label class="form-label" for="description">What would you like us to know? <span class="text-muted-custom fw-normal">(optional)</span></label><textarea class="form-control" id="description" name="description" maxlength="2000" placeholder="Share a short note about your appointment."><?= e($description) ?></textarea></div>
                <div class="col-12 d-flex flex-column flex-sm-row gap-2 mt-4"><button class="btn btn-primary px-4" type="submit">Request appointment</button><a class="btn btn-outline-secondary px-4" href="<?= e(url('dashboard.php')) ?>">Back to dashboard</a></div>
            </div>
        </form>
    </div>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
